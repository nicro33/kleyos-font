# Kleyos 1.0.0 — QA Report

**Status:** PASS with known brush-style contour contacts.

## Binary integrity
| Check | Display | Text |
|---|---:|---:|
| Glyphs | 124 | 124 |
| Encoded characters | 123 | 123 |
| UPM | 1000 | 1000 |
| Legacy kern pairs | 83 | 83 |
| GPOS | yes | yes |
| fsType | 0 | 0 |
| Vendor ID | KLYS | KLYS |
| Required characters missing | none | none |

## WOFF2
Roundtrip TTF → WOFF2 preserves cmap, glyph order, horizontal metrics,
kern count and outline signatures for both roles.

## 676 lowercase pairs
Pairs with contour contact:
`ao, eo, ho, ko, qo, uo, wo, xo, zo`

These are existing brush-style contacts associated with `o`.
The V1.4-F change only modifies capital `Ç`.

## Remaining publication checks
- Run FontBakery before Google Fonts submission.
- Test Safari / Chrome / Firefox and major OSes.
- Decide whether `Kleyos` should be a Reserved Font Name before public publication.
